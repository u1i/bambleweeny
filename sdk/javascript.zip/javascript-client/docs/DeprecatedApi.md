# Bambleweeny.DeprecatedApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**dELETEResource**](DeprecatedApi.md#dELETEResource) | **DELETE** /resources/{id} | Delete Resource
[**gETResource**](DeprecatedApi.md#gETResource) | **GET** /resources/{id} | Get Resource
[**lISTResources**](DeprecatedApi.md#lISTResources) | **GET** /resources | List Resources
[**pOSTResource**](DeprecatedApi.md#pOSTResource) | **POST** /resources | Create Resource


<a name="dELETEResource"></a>
# **dELETEResource**
> dELETEResource(id)

Delete Resource

Delete a resource identified by a UUID.

### Example
```javascript
var Bambleweeny = require('bambleweeny');
var defaultClient = Bambleweeny.ApiClient.instance;

// Configure OAuth2 access token for authorization: oauth2
var oauth2 = defaultClient.authentications['oauth2'];
oauth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new Bambleweeny.DeprecatedApi();

var id = "id_example"; // String | 


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.dELETEResource(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 

### Return type

null (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="gETResource"></a>
# **gETResource**
> InlineResponse2005 gETResource(id)

Get Resource

Retrieve a resource identified by the UUID.

### Example
```javascript
var Bambleweeny = require('bambleweeny');
var defaultClient = Bambleweeny.ApiClient.instance;

// Configure OAuth2 access token for authorization: oauth2
var oauth2 = defaultClient.authentications['oauth2'];
oauth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new Bambleweeny.DeprecatedApi();

var id = "id_example"; // String | 


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.gETResource(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 

### Return type

[**InlineResponse2005**](InlineResponse2005.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="lISTResources"></a>
# **lISTResources**
> InlineResponse2004 lISTResources()

List Resources

List all resources of the user. Admin will see a list of resources for all users.

### Example
```javascript
var Bambleweeny = require('bambleweeny');
var defaultClient = Bambleweeny.ApiClient.instance;

// Configure OAuth2 access token for authorization: oauth2
var oauth2 = defaultClient.authentications['oauth2'];
oauth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new Bambleweeny.DeprecatedApi();

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.lISTResources(callback);
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2004**](InlineResponse2004.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="pOSTResource"></a>
# **pOSTResource**
> Object pOSTResource(opts)

Create Resource

Create a resource from JSON data.

### Example
```javascript
var Bambleweeny = require('bambleweeny');
var defaultClient = Bambleweeny.ApiClient.instance;

// Configure OAuth2 access token for authorization: oauth2
var oauth2 = defaultClient.authentications['oauth2'];
oauth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new Bambleweeny.DeprecatedApi();

var opts = { 
  'body': new Bambleweeny.Body4() // Body4 | 
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.pOSTResource(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body4**](Body4.md)|  | [optional] 

### Return type

**Object**

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

