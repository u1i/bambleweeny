# Bambleweeny.UsersApi

All URIs are relative to *https://localhost/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**dELETEUser**](UsersApi.md#dELETEUser) | **DELETE** /users/{id} | Delete User
[**gETUser**](UsersApi.md#gETUser) | **GET** /users/{id} | Get User
[**lISTUsers**](UsersApi.md#lISTUsers) | **GET** /users | List Users
[**pOSTUser**](UsersApi.md#pOSTUser) | **POST** /users | Create User
[**pUTUser**](UsersApi.md#pUTUser) | **PUT** /users/{id} | Set Quota


<a name="dELETEUser"></a>
# **dELETEUser**
> dELETEUser(id)

Delete User

Delete a user record identified by a numceric user id.

### Example
```javascript
var Bambleweeny = require('bambleweeny');
var defaultClient = Bambleweeny.ApiClient.instance;

// Configure OAuth2 access token for authorization: oauth2
var oauth2 = defaultClient.authentications['oauth2'];
oauth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new Bambleweeny.UsersApi();

var id = "id_example"; // String | 


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.dELETEUser(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 

### Return type

null (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="gETUser"></a>
# **gETUser**
> InlineResponse2003 gETUser(id)

Get User

Get a user record identified by a numceric user id.

### Example
```javascript
var Bambleweeny = require('bambleweeny');
var defaultClient = Bambleweeny.ApiClient.instance;

// Configure OAuth2 access token for authorization: oauth2
var oauth2 = defaultClient.authentications['oauth2'];
oauth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new Bambleweeny.UsersApi();

var id = "id_example"; // String | 


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.gETUser(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 

### Return type

[**InlineResponse2003**](InlineResponse2003.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="lISTUsers"></a>
# **lISTUsers**
> InlineResponse2004 lISTUsers()

List Users

List all users in the system.

### Example
```javascript
var Bambleweeny = require('bambleweeny');
var defaultClient = Bambleweeny.ApiClient.instance;

// Configure OAuth2 access token for authorization: oauth2
var oauth2 = defaultClient.authentications['oauth2'];
oauth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new Bambleweeny.UsersApi();

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.lISTUsers(callback);
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2004**](InlineResponse2004.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="pOSTUser"></a>
# **pOSTUser**
> InlineResponse201 pOSTUser(opts)

Create User

Create a user. The new user can then make authenticated requests with access tokens retrieved from the /auth/token endpoint.

### Example
```javascript
var Bambleweeny = require('bambleweeny');
var defaultClient = Bambleweeny.ApiClient.instance;

// Configure OAuth2 access token for authorization: oauth2
var oauth2 = defaultClient.authentications['oauth2'];
oauth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new Bambleweeny.UsersApi();

var opts = { 
  'body': new Bambleweeny.Body3() // Body3 | 
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.pOSTUser(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body3**](Body3.md)|  | [optional] 

### Return type

[**InlineResponse201**](InlineResponse201.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="pUTUser"></a>
# **pUTUser**
> InlineResponse403 pUTUser(id, opts)

Set Quota

Set the quota for a user (number of resources a user can have).

### Example
```javascript
var Bambleweeny = require('bambleweeny');
var defaultClient = Bambleweeny.ApiClient.instance;

// Configure OAuth2 access token for authorization: oauth2
var oauth2 = defaultClient.authentications['oauth2'];
oauth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new Bambleweeny.UsersApi();

var id = "id_example"; // String | 

var opts = { 
  'body': new Bambleweeny.Body2() // Body2 | 
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.pUTUser(id, opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **body** | [**Body2**](Body2.md)|  | [optional] 

### Return type

[**InlineResponse403**](InlineResponse403.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

