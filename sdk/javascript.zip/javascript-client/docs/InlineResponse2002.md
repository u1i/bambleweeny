# Bambleweeny.InlineResponse2002

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resources** | [**[InlineResponse2002Resources]**](InlineResponse2002Resources.md) |  | [optional] 


