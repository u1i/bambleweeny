# Bambleweeny.ListsApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**dELETEListsId**](ListsApi.md#dELETEListsId) | **DELETE** /lists/{id} | Delete List
[**gETLists**](ListsApi.md#gETLists) | **GET** /lists | Get All Lists
[**gETListsId**](ListsApi.md#gETListsId) | **GET** /lists/{id} | Get Item from List
[**pOSTListsId**](ListsApi.md#pOSTListsId) | **POST** /lists/{id} | Add Item to List


<a name="dELETEListsId"></a>
# **dELETEListsId**
> Object dELETEListsId(id)

Delete List

Removes a list.

### Example
```javascript
var Bambleweeny = require('bambleweeny');

var apiInstance = new Bambleweeny.ListsApi();

var id = "id_example"; // String | 


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.dELETEListsId(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 

### Return type

**Object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: text/plain
 - **Accept**: application/json

<a name="gETLists"></a>
# **gETLists**
> gETLists()

Get All Lists

Gets all lists.

### Example
```javascript
var Bambleweeny = require('bambleweeny');

var apiInstance = new Bambleweeny.ListsApi();

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.gETLists(callback);
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: text/plain
 - **Accept**: application/json

<a name="gETListsId"></a>
# **gETListsId**
> gETListsId(id)

Get Item from List

Retrieves the last item from a list (\&quot;pop\&quot;).

### Example
```javascript
var Bambleweeny = require('bambleweeny');

var apiInstance = new Bambleweeny.ListsApi();

var id = "id_example"; // String | 


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.gETListsId(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: text/plain
 - **Accept**: application/json

<a name="pOSTListsId"></a>
# **pOSTListsId**
> pOSTListsId(id)

Add Item to List

Adds an item to a list (\&quot;push\&quot;). The list will be created if it doesn&#39;t exist yet.

### Example
```javascript
var Bambleweeny = require('bambleweeny');

var apiInstance = new Bambleweeny.ListsApi();

var id = "id_example"; // String | 


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.pOSTListsId(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: text/plain
 - **Accept**: application/json

