# Bambleweeny.AuthApi

All URIs are relative to *https://localhost/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**pOSTAuthToken**](AuthApi.md#pOSTAuthToken) | **POST** /auth/token | Get Access Token


<a name="pOSTAuthToken"></a>
# **pOSTAuthToken**
> InlineResponse2002 pOSTAuthToken(opts)

Get Access Token

### Example
```javascript
var Bambleweeny = require('bambleweeny');

var apiInstance = new Bambleweeny.AuthApi();

var opts = { 
  'body': new Bambleweeny.Body1() // Body1 | 
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.pOSTAuthToken(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body1**](Body1.md)|  | [optional] 

### Return type

[**InlineResponse2002**](InlineResponse2002.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

