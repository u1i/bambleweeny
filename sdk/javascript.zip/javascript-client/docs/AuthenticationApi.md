# Bambleweeny.AuthenticationApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**pOSTAuthToken**](AuthenticationApi.md#pOSTAuthToken) | **POST** /auth/token | Get Access Token


<a name="pOSTAuthToken"></a>
# **pOSTAuthToken**
> InlineResponse200 pOSTAuthToken(opts)

Get Access Token

This endpoint is used to retrieve an access token to perform authenticated requests against the &#39;resources&#39; endpoints. Login with username (email) and password. For admin, the username is simply &#39;admin&#39;.

### Example
```javascript
var Bambleweeny = require('bambleweeny');

var apiInstance = new Bambleweeny.AuthenticationApi();

var opts = { 
  'body': new Bambleweeny.Body() // Body | 
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.pOSTAuthToken(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body**](Body.md)|  | [optional] 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

