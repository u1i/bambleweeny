# Bambleweeny.RoutesApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cREATERoute**](RoutesApi.md#cREATERoute) | **POST** /routes | Create Route
[**rOUTEKey**](RoutesApi.md#rOUTEKey) | **GET** /routes/{id} | Read Key


<a name="cREATERoute"></a>
# **cREATERoute**
> InlineResponse2002 cREATERoute(opts)

Create Route

Creates a public endpoint for a key.

### Example
```javascript
var Bambleweeny = require('bambleweeny');
var defaultClient = Bambleweeny.ApiClient.instance;

// Configure OAuth2 access token for authorization: oauth2
var oauth2 = defaultClient.authentications['oauth2'];
oauth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new Bambleweeny.RoutesApi();

var opts = { 
  'body': new Bambleweeny.Body1() // Body1 | 
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.cREATERoute(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body1**](Body1.md)|  | [optional] 

### Return type

[**InlineResponse2002**](InlineResponse2002.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="rOUTEKey"></a>
# **rOUTEKey**
> rOUTEKey(id)

Read Key

Reads a key from a public route.

### Example
```javascript
var Bambleweeny = require('bambleweeny');

var apiInstance = new Bambleweeny.RoutesApi();

var id = "id_example"; // String | 


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.rOUTEKey(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

