# Bambleweeny.InlineResponse2004

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resources** | [**[InlineResponse2004Resources]**](InlineResponse2004Resources.md) |  | [optional] 


