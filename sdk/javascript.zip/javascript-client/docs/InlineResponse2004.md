# Bambleweeny.InlineResponse2004

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**users** | [**[InlineResponse2004Users]**](InlineResponse2004Users.md) |  | [optional] 


