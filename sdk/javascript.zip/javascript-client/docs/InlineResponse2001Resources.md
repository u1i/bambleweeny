# Bambleweeny.InlineResponse2001Resources

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**owner** | **String** |  | [optional] 
**id** | **String** |  | [optional] 
**acl** | **String** |  | [optional] 


