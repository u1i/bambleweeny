# Bambleweeny.InlineResponse2001

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resources** | [**[InlineResponse2001Resources]**](InlineResponse2001Resources.md) |  | [optional] 


