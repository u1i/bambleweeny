# Bambleweeny.InlineResponse2001

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**keys** | [**[InlineResponse2001Keys]**](InlineResponse2001Keys.md) |  | [optional] 


