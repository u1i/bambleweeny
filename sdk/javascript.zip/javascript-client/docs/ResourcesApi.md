# Bambleweeny.ResourcesApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**dELETEResource**](ResourcesApi.md#dELETEResource) | **DELETE** /resources/{id} | Delete Resource
[**gETResource**](ResourcesApi.md#gETResource) | **GET** /resources/{id} | Get Resource
[**lISTResources**](ResourcesApi.md#lISTResources) | **GET** /resources | List Resources
[**pOSTResource**](ResourcesApi.md#pOSTResource) | **POST** /resources | Create Resource


<a name="dELETEResource"></a>
# **dELETEResource**
> dELETEResource(id)

Delete Resource

Delete a resource identified by a UUID.

### Example
```javascript
var Bambleweeny = require('bambleweeny');
var defaultClient = Bambleweeny.ApiClient.instance;

// Configure OAuth2 access token for authorization: oauth2
var oauth2 = defaultClient.authentications['oauth2'];
oauth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new Bambleweeny.ResourcesApi();

var id = "id_example"; // String | 


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.dELETEResource(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 

### Return type

null (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="gETResource"></a>
# **gETResource**
> InlineResponse2001 gETResource(id)

Get Resource

Retrieve a resource identified by the UUID.

### Example
```javascript
var Bambleweeny = require('bambleweeny');
var defaultClient = Bambleweeny.ApiClient.instance;

// Configure OAuth2 access token for authorization: oauth2
var oauth2 = defaultClient.authentications['oauth2'];
oauth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new Bambleweeny.ResourcesApi();

var id = "id_example"; // String | 


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.gETResource(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 

### Return type

[**InlineResponse2001**](InlineResponse2001.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="lISTResources"></a>
# **lISTResources**
> InlineResponse2002 lISTResources()

List Resources

List all resources of the user. Admin will see a list of resources for all users.

### Example
```javascript
var Bambleweeny = require('bambleweeny');
var defaultClient = Bambleweeny.ApiClient.instance;

// Configure OAuth2 access token for authorization: oauth2
var oauth2 = defaultClient.authentications['oauth2'];
oauth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new Bambleweeny.ResourcesApi();

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.lISTResources(callback);
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2002**](InlineResponse2002.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="pOSTResource"></a>
# **pOSTResource**
> Object pOSTResource(opts)

Create Resource

Create a resource from JSON data.

### Example
```javascript
var Bambleweeny = require('bambleweeny');
var defaultClient = Bambleweeny.ApiClient.instance;

// Configure OAuth2 access token for authorization: oauth2
var oauth2 = defaultClient.authentications['oauth2'];
oauth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new Bambleweeny.ResourcesApi();

var opts = { 
  'body': new Bambleweeny.Body1() // Body1 | 
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.pOSTResource(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body1**](Body1.md)|  | [optional] 

### Return type

**Object**

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

