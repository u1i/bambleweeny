# Bambleweeny.ConfigApi

All URIs are relative to *https://localhost/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**pUTConfigAdmin**](ConfigApi.md#pUTConfigAdmin) | **PUT** /config/admin | Change Admin Password


<a name="pUTConfigAdmin"></a>
# **pUTConfigAdmin**
> pUTConfigAdmin(opts)

Change Admin Password

Update the admin password - default password is &#39;changeme&#39;.

### Example
```javascript
var Bambleweeny = require('bambleweeny');
var defaultClient = Bambleweeny.ApiClient.instance;

// Configure OAuth2 access token for authorization: oauth2
var oauth2 = defaultClient.authentications['oauth2'];
oauth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new Bambleweeny.ConfigApi();

var opts = { 
  'body': new Bambleweeny.Body4() // Body4 | 
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.pUTConfigAdmin(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body4**](Body4.md)|  | [optional] 

### Return type

null (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

