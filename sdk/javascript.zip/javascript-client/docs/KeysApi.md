# Bambleweeny.KeysApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**dELKey**](KeysApi.md#dELKey) | **DELETE** /keys/(id} | Delete Key
[**iNCRKey**](KeysApi.md#iNCRKey) | **GET** /incr/(id} | Increase Key
[**rEADKey**](KeysApi.md#rEADKey) | **GET** /keys/ | List Keys
[**rEADKey_0**](KeysApi.md#rEADKey_0) | **GET** /keys/(id} | Read Key
[**wRITEKey**](KeysApi.md#wRITEKey) | **PUT** /keys/(id} | Write Key


<a name="dELKey"></a>
# **dELKey**
> Object dELKey()

Delete Key

Deletes a key.

### Example
```javascript
var Bambleweeny = require('bambleweeny');
var defaultClient = Bambleweeny.ApiClient.instance;

// Configure OAuth2 access token for authorization: oauth2
var oauth2 = defaultClient.authentications['oauth2'];
oauth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new Bambleweeny.KeysApi();

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.dELKey(callback);
```

### Parameters
This endpoint does not need any parameter.

### Return type

**Object**

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="iNCRKey"></a>
# **iNCRKey**
> iNCRKey()

Increase Key

Increments the number stored at key by one.

### Example
```javascript
var Bambleweeny = require('bambleweeny');
var defaultClient = Bambleweeny.ApiClient.instance;

// Configure OAuth2 access token for authorization: oauth2
var oauth2 = defaultClient.authentications['oauth2'];
oauth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new Bambleweeny.KeysApi();

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.iNCRKey(callback);
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: text/plain

<a name="rEADKey"></a>
# **rEADKey**
> rEADKey()

List Keys

List all keys.

### Example
```javascript
var Bambleweeny = require('bambleweeny');
var defaultClient = Bambleweeny.ApiClient.instance;

// Configure OAuth2 access token for authorization: oauth2
var oauth2 = defaultClient.authentications['oauth2'];
oauth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new Bambleweeny.KeysApi();

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.rEADKey(callback);
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="rEADKey_0"></a>
# **rEADKey_0**
> rEADKey_0()

Read Key

Read a key.

### Example
```javascript
var Bambleweeny = require('bambleweeny');
var defaultClient = Bambleweeny.ApiClient.instance;

// Configure OAuth2 access token for authorization: oauth2
var oauth2 = defaultClient.authentications['oauth2'];
oauth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new Bambleweeny.KeysApi();

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.rEADKey_0(callback);
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: text/plain

<a name="wRITEKey"></a>
# **wRITEKey**
> wRITEKey()

Write Key

Set key to a specific value. Key names contain numbers, characters, underscores and colons. Valid key names are &#39;foo&#39;, &#39;my_key1&#39;, &#39;debug:b1:Hello&#39; &#39;RogerRabbit&#39;.

### Example
```javascript
var Bambleweeny = require('bambleweeny');
var defaultClient = Bambleweeny.ApiClient.instance;

// Configure OAuth2 access token for authorization: oauth2
var oauth2 = defaultClient.authentications['oauth2'];
oauth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new Bambleweeny.KeysApi();

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.wRITEKey(callback);
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

