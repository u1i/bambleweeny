# Bambleweeny.InlineResponse2004Resources

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**owner** | **String** |  | [optional] 
**id** | **String** |  | [optional] 
**acl** | **String** |  | [optional] 


