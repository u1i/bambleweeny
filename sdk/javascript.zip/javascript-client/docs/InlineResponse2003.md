# Bambleweeny.InlineResponse2003

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**users** | [**[InlineResponse2003Users]**](InlineResponse2003Users.md) |  | [optional] 


