# SwaggerClient::ListsApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**d_elete_lists_id**](ListsApi.md#d_elete_lists_id) | **DELETE** /lists/{id} | Delete List
[**g_et_lists**](ListsApi.md#g_et_lists) | **GET** /lists | Get All Lists
[**g_et_lists_id**](ListsApi.md#g_et_lists_id) | **GET** /lists/{id} | Get Item from List
[**p_ost_lists_id**](ListsApi.md#p_ost_lists_id) | **POST** /lists/{id} | Add Item to List


# **d_elete_lists_id**
> Object d_elete_lists_id(id)

Delete List

Removes a list.

### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::ListsApi.new

id = "id_example" # String | 


begin
  #Delete List
  result = api_instance.d_elete_lists_id(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ListsApi->d_elete_lists_id: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 

### Return type

**Object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: text/plain
 - **Accept**: application/json



# **g_et_lists**
> g_et_lists

Get All Lists

Gets all lists.

### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::ListsApi.new

begin
  #Get All Lists
  api_instance.g_et_lists
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ListsApi->g_et_lists: #{e}"
end
```

### Parameters
This endpoint does not need any parameter.

### Return type

nil (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: text/plain
 - **Accept**: application/json



# **g_et_lists_id**
> g_et_lists_id(id)

Get Item from List

Retrieves the last item from a list (\"pop\").

### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::ListsApi.new

id = "id_example" # String | 


begin
  #Get Item from List
  api_instance.g_et_lists_id(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ListsApi->g_et_lists_id: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 

### Return type

nil (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: text/plain
 - **Accept**: application/json



# **p_ost_lists_id**
> p_ost_lists_id(id)

Add Item to List

Adds an item to a list (\"push\"). The list will be created if it doesn't exist yet.

### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::ListsApi.new

id = "id_example" # String | 


begin
  #Add Item to List
  api_instance.p_ost_lists_id(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ListsApi->p_ost_lists_id: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 

### Return type

nil (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: text/plain
 - **Accept**: application/json



