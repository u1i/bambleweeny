# SwaggerClient::AuthApi

All URIs are relative to *https://localhost/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**p_ost_auth_token**](AuthApi.md#p_ost_auth_token) | **POST** /auth/token | Get Access Token


# **p_ost_auth_token**
> InlineResponse2002 p_ost_auth_token(opts)

Get Access Token

### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::AuthApi.new

opts = { 
  body: SwaggerClient::Body1.new # Body1 | 
}

begin
  #Get Access Token
  result = api_instance.p_ost_auth_token(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling AuthApi->p_ost_auth_token: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body1**](Body1.md)|  | [optional] 

### Return type

[**InlineResponse2002**](InlineResponse2002.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



