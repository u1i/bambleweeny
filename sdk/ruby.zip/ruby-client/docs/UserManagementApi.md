# SwaggerClient::UserManagementApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**d_elete_user**](UserManagementApi.md#d_elete_user) | **DELETE** /users/{id} | Delete User
[**g_et_user**](UserManagementApi.md#g_et_user) | **GET** /users/{id} | Get User
[**l_ist_users**](UserManagementApi.md#l_ist_users) | **GET** /users | List Users
[**p_ost_user**](UserManagementApi.md#p_ost_user) | **POST** /users | Create User
[**p_ut_user**](UserManagementApi.md#p_ut_user) | **PUT** /users/{id} | Set Quota


# **d_elete_user**
> d_elete_user(id)

Delete User

Delete a user record identified by a numceric user id.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: oauth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::UserManagementApi.new

id = "id_example" # String | 


begin
  #Delete User
  api_instance.d_elete_user(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling UserManagementApi->d_elete_user: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 

### Return type

nil (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **g_et_user**
> InlineResponse2003 g_et_user(id)

Get User

Get a user record identified by a numceric user id.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: oauth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::UserManagementApi.new

id = "id_example" # String | 


begin
  #Get User
  result = api_instance.g_et_user(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling UserManagementApi->g_et_user: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 

### Return type

[**InlineResponse2003**](InlineResponse2003.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **l_ist_users**
> InlineResponse2004 l_ist_users

List Users

List all users in the system.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: oauth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::UserManagementApi.new

begin
  #List Users
  result = api_instance.l_ist_users
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling UserManagementApi->l_ist_users: #{e}"
end
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2004**](InlineResponse2004.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **p_ost_user**
> InlineResponse201 p_ost_user(opts)

Create User

Create a user. The new user can then make authenticated requests with access tokens retrieved from the /auth/token endpoint.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: oauth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::UserManagementApi.new

opts = { 
  body: SwaggerClient::Body3.new # Body3 | 
}

begin
  #Create User
  result = api_instance.p_ost_user(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling UserManagementApi->p_ost_user: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body3**](Body3.md)|  | [optional] 

### Return type

[**InlineResponse201**](InlineResponse201.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **p_ut_user**
> InlineResponse403 p_ut_user(id, opts)

Set Quota

Set the quota for a user (number of resources a user can have).

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: oauth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::UserManagementApi.new

id = "id_example" # String | 

opts = { 
  body: SwaggerClient::Body2.new # Body2 | 
}

begin
  #Set Quota
  result = api_instance.p_ut_user(id, opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling UserManagementApi->p_ut_user: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **body** | [**Body2**](Body2.md)|  | [optional] 

### Return type

[**InlineResponse403**](InlineResponse403.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



