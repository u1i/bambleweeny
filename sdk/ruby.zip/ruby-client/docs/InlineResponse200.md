# SwaggerClient::InlineResponse200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**access_token** | **String** |  | [optional] 
**token_type** | **String** |  | [optional] 


