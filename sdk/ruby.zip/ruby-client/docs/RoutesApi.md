# SwaggerClient::RoutesApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**c_reate_route**](RoutesApi.md#c_reate_route) | **POST** /routes | Create Route
[**r_oute_key**](RoutesApi.md#r_oute_key) | **GET** /routes/{id} | Read Key


# **c_reate_route**
> InlineResponse2002 c_reate_route(opts)

Create Route

Creates a public endpoint for a key.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: oauth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::RoutesApi.new

opts = { 
  body: SwaggerClient::Body1.new # Body1 | 
}

begin
  #Create Route
  result = api_instance.c_reate_route(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling RoutesApi->c_reate_route: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body1**](Body1.md)|  | [optional] 

### Return type

[**InlineResponse2002**](InlineResponse2002.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **r_oute_key**
> r_oute_key(id)

Read Key

Reads a key from a public route.

### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::RoutesApi.new

id = "id_example" # String | 


begin
  #Read Key
  api_instance.r_oute_key(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling RoutesApi->r_oute_key: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 

### Return type

nil (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



