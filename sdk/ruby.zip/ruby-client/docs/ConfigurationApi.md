# SwaggerClient::ConfigurationApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**p_ut_config_admin**](ConfigurationApi.md#p_ut_config_admin) | **PUT** /config/admin | Change Admin Password


# **p_ut_config_admin**
> p_ut_config_admin(opts)

Change Admin Password

Update the admin password - default password is 'changeme'.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: oauth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ConfigurationApi.new

opts = { 
  body: SwaggerClient::Body3.new # Body3 | 
}

begin
  #Change Admin Password
  api_instance.p_ut_config_admin(opts)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ConfigurationApi->p_ut_config_admin: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body3**](Body3.md)|  | [optional] 

### Return type

nil (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



