# SwaggerClient::InlineResponse2004

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**users** | [**Array&lt;InlineResponse2004Users&gt;**](InlineResponse2004Users.md) |  | [optional] 


