# SwaggerClient::InlineResponse2004

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resources** | [**Array&lt;InlineResponse2004Resources&gt;**](InlineResponse2004Resources.md) |  | [optional] 


