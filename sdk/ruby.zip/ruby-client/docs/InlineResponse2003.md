# SwaggerClient::InlineResponse2003

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**users** | [**Array&lt;InlineResponse2003Users&gt;**](InlineResponse2003Users.md) |  | [optional] 


