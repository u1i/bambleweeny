# SwaggerClient::InlineResponse2001

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**keys** | [**Array&lt;InlineResponse2001Keys&gt;**](InlineResponse2001Keys.md) |  | [optional] 


