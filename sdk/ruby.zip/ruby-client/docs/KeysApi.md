# SwaggerClient::KeysApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**d_el_key**](KeysApi.md#d_el_key) | **DELETE** /keys/(id} | Delete Key
[**i_ncr_key**](KeysApi.md#i_ncr_key) | **GET** /incr/(id} | Increase Key
[**r_ead_key**](KeysApi.md#r_ead_key) | **GET** /keys/ | List Keys
[**r_ead_key_0**](KeysApi.md#r_ead_key_0) | **GET** /keys/(id} | Read Key
[**w_rite_key**](KeysApi.md#w_rite_key) | **PUT** /keys/(id} | Write Key


# **d_el_key**
> Object d_el_key

Delete Key

Deletes a key.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: oauth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::KeysApi.new

begin
  #Delete Key
  result = api_instance.d_el_key
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling KeysApi->d_el_key: #{e}"
end
```

### Parameters
This endpoint does not need any parameter.

### Return type

**Object**

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **i_ncr_key**
> i_ncr_key

Increase Key

Increments the number stored at key by one.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: oauth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::KeysApi.new

begin
  #Increase Key
  api_instance.i_ncr_key
rescue SwaggerClient::ApiError => e
  puts "Exception when calling KeysApi->i_ncr_key: #{e}"
end
```

### Parameters
This endpoint does not need any parameter.

### Return type

nil (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: text/plain



# **r_ead_key**
> r_ead_key

List Keys

List all keys.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: oauth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::KeysApi.new

begin
  #List Keys
  api_instance.r_ead_key
rescue SwaggerClient::ApiError => e
  puts "Exception when calling KeysApi->r_ead_key: #{e}"
end
```

### Parameters
This endpoint does not need any parameter.

### Return type

nil (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **r_ead_key_0**
> r_ead_key_0

Read Key

Read a key.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: oauth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::KeysApi.new

begin
  #Read Key
  api_instance.r_ead_key_0
rescue SwaggerClient::ApiError => e
  puts "Exception when calling KeysApi->r_ead_key_0: #{e}"
end
```

### Parameters
This endpoint does not need any parameter.

### Return type

nil (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: text/plain



# **w_rite_key**
> w_rite_key

Write Key

Set key to a specific value. Key names contain numbers, characters, underscores and colons. Valid key names are 'foo', 'my_key1', 'debug:b1:Hello' 'RogerRabbit'.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: oauth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::KeysApi.new

begin
  #Write Key
  api_instance.w_rite_key
rescue SwaggerClient::ApiError => e
  puts "Exception when calling KeysApi->w_rite_key: #{e}"
end
```

### Parameters
This endpoint does not need any parameter.

### Return type

nil (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



