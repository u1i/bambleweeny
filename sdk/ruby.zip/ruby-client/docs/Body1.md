# SwaggerClient::Body1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **String** |  | [optional] 
**content_type** | **String** |  | [optional] 


