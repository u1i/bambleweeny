# SwaggerClient::Body1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**quota** | **String** |  | 


