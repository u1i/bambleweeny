# SwaggerClient::AuthenticationApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**p_ost_auth_token**](AuthenticationApi.md#p_ost_auth_token) | **POST** /auth/token | Get Access Token


# **p_ost_auth_token**
> InlineResponse200 p_ost_auth_token(opts)

Get Access Token

This endpoint is used to retrieve an access token to perform authenticated requests against the 'resources' endpoints. Login with username (email) and password. For admin, the username is simply 'admin'.

### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::AuthenticationApi.new

opts = { 
  body: SwaggerClient::Body.new # Body | 
}

begin
  #Get Access Token
  result = api_instance.p_ost_auth_token(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling AuthenticationApi->p_ost_auth_token: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body**](Body.md)|  | [optional] 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



