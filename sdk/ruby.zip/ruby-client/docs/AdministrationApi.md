# SwaggerClient::AdministrationApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**c_hange_admin_pw**](AdministrationApi.md#c_hange_admin_pw) | **PUT** /config/admin | Change Admin Password
[**d_elete_user**](AdministrationApi.md#d_elete_user) | **DELETE** /users/{id} | Delete User
[**g_et_info**](AdministrationApi.md#g_et_info) | **GET** /info | Get Info
[**g_et_user**](AdministrationApi.md#g_et_user) | **GET** /users/{id} | Get User
[**l_ist_users**](AdministrationApi.md#l_ist_users) | **GET** /users | List Users
[**p_ost_user**](AdministrationApi.md#p_ost_user) | **POST** /users | Create User
[**p_ut_user**](AdministrationApi.md#p_ut_user) | **PUT** /users/{id} | Set Quota
[**s_ave**](AdministrationApi.md#s_ave) | **GET** /save | Save to Disk


# **c_hange_admin_pw**
> c_hange_admin_pw(opts)

Change Admin Password

Update the admin password - default password is 'changeme'.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: oauth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::AdministrationApi.new

opts = { 
  body: SwaggerClient::Body4.new # Body4 | 
}

begin
  #Change Admin Password
  api_instance.c_hange_admin_pw(opts)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling AdministrationApi->c_hange_admin_pw: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body4**](Body4.md)|  | [optional] 

### Return type

nil (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **d_elete_user**
> d_elete_user(id)

Delete User

Delete a user record identified by a numceric user id.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: oauth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::AdministrationApi.new

id = "id_example" # String | 


begin
  #Delete User
  api_instance.d_elete_user(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling AdministrationApi->d_elete_user: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 

### Return type

nil (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **g_et_info**
> g_et_info

Get Info

Gets detailed information on the backend Redis connection, including memory used, number of connections etc.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: oauth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::AdministrationApi.new

begin
  #Get Info
  api_instance.g_et_info
rescue SwaggerClient::ApiError => e
  puts "Exception when calling AdministrationApi->g_et_info: #{e}"
end
```

### Parameters
This endpoint does not need any parameter.

### Return type

nil (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **g_et_user**
> InlineResponse2004 g_et_user(id)

Get User

Get a user record identified by a numceric user id.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: oauth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::AdministrationApi.new

id = "id_example" # String | 


begin
  #Get User
  result = api_instance.g_et_user(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling AdministrationApi->g_et_user: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 

### Return type

[**InlineResponse2004**](InlineResponse2004.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **l_ist_users**
> InlineResponse2003 l_ist_users

List Users

List all users in the system.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: oauth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::AdministrationApi.new

begin
  #List Users
  result = api_instance.l_ist_users
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling AdministrationApi->l_ist_users: #{e}"
end
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2003**](InlineResponse2003.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **p_ost_user**
> InlineResponse201 p_ost_user(opts)

Create User

Create a user. The new user can then make authenticated requests with access tokens retrieved from the /auth/token endpoint.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: oauth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::AdministrationApi.new

opts = { 
  body: SwaggerClient::Body2.new # Body2 | 
}

begin
  #Create User
  result = api_instance.p_ost_user(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling AdministrationApi->p_ost_user: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body2**](Body2.md)|  | [optional] 

### Return type

[**InlineResponse201**](InlineResponse201.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **p_ut_user**
> InlineResponse403 p_ut_user(id, opts)

Set Quota

Set the quota for a user (number of resources a user can have).

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: oauth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::AdministrationApi.new

id = "id_example" # String | 

opts = { 
  body: SwaggerClient::Body3.new # Body3 | 
}

begin
  #Set Quota
  result = api_instance.p_ut_user(id, opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling AdministrationApi->p_ut_user: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 
 **body** | [**Body3**](Body3.md)|  | [optional] 

### Return type

[**InlineResponse403**](InlineResponse403.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **s_ave**
> s_ave

Save to Disk

Triggers a save to disk for the backend Redis in-memory database.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: oauth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::AdministrationApi.new

begin
  #Save to Disk
  api_instance.s_ave
rescue SwaggerClient::ApiError => e
  puts "Exception when calling AdministrationApi->s_ave: #{e}"
end
```

### Parameters
This endpoint does not need any parameter.

### Return type

nil (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



