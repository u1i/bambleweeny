# SwaggerClient::InlineResponse2002

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**access_token** | **String** |  | [optional] 
**token_type** | **String** |  | [optional] 


