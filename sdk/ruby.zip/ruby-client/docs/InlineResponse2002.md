# SwaggerClient::InlineResponse2002

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resources** | [**Array&lt;InlineResponse2002Resources&gt;**](InlineResponse2002Resources.md) |  | [optional] 


