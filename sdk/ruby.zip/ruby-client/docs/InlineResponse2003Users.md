# SwaggerClient::InlineResponse2003Users

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | [optional] 
**email** | **String** |  | [optional] 
**quota** | **String** |  | [optional] 


