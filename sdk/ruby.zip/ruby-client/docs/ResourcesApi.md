# SwaggerClient::ResourcesApi

All URIs are relative to *https://localhost/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**d_elete_resource**](ResourcesApi.md#d_elete_resource) | **DELETE** /resources/{id} | Delete Resource
[**g_et_resource**](ResourcesApi.md#g_et_resource) | **GET** /resources/{id} | Get Resource
[**l_ist_resources**](ResourcesApi.md#l_ist_resources) | **GET** /resources | List Resources
[**p_ost_resource**](ResourcesApi.md#p_ost_resource) | **POST** /resources | Create Resource


# **d_elete_resource**
> d_elete_resource(id)

Delete Resource

Delete a resource identified by a UUID.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: oauth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ResourcesApi.new

id = "id_example" # String | 


begin
  #Delete Resource
  api_instance.d_elete_resource(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ResourcesApi->d_elete_resource: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 

### Return type

nil (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **g_et_resource**
> InlineResponse200 g_et_resource(id)

Get Resource

Retrieve a resource identified by the UUID.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: oauth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ResourcesApi.new

id = "id_example" # String | 


begin
  #Get Resource
  result = api_instance.g_et_resource(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ResourcesApi->g_et_resource: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  | 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **l_ist_resources**
> InlineResponse2001 l_ist_resources

List Resources

List all resources of the user. Admin will see a list of resources for all users.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: oauth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ResourcesApi.new

begin
  #List Resources
  result = api_instance.l_ist_resources
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ResourcesApi->l_ist_resources: #{e}"
end
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2001**](InlineResponse2001.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **p_ost_resource**
> Object p_ost_resource(opts)

Create Resource

Create a resource from JSON data.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: oauth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ResourcesApi.new

opts = { 
  body: SwaggerClient::Body.new # Body | 
}

begin
  #Create Resource
  result = api_instance.p_ost_resource(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ResourcesApi->p_ost_resource: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body**](Body.md)|  | [optional] 

### Return type

**Object**

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



