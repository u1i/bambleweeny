# swagger_client.UserManagementApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**d_elete_user**](UserManagementApi.md#d_elete_user) | **DELETE** /users/{id} | Delete User
[**g_et_user**](UserManagementApi.md#g_et_user) | **GET** /users/{id} | Get User
[**l_ist_users**](UserManagementApi.md#l_ist_users) | **GET** /users | List Users
[**p_ost_user**](UserManagementApi.md#p_ost_user) | **POST** /users | Create User
[**p_ut_user**](UserManagementApi.md#p_ut_user) | **PUT** /users/{id} | Set Quota


# **d_elete_user**
> d_elete_user(id)

Delete User

Delete a user record identified by a numceric user id.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: oauth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.UserManagementApi(swagger_client.ApiClient(configuration))
id = 'id_example' # str | 

try:
    # Delete User
    api_instance.d_elete_user(id)
except ApiException as e:
    print("Exception when calling UserManagementApi->d_elete_user: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **g_et_user**
> InlineResponse2002 g_et_user(id)

Get User

Get a user record identified by a numceric user id.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: oauth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.UserManagementApi(swagger_client.ApiClient(configuration))
id = 'id_example' # str | 

try:
    # Get User
    api_response = api_instance.g_et_user(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UserManagementApi->g_et_user: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**|  | 

### Return type

[**InlineResponse2002**](InlineResponse2002.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **l_ist_users**
> InlineResponse2003 l_ist_users()

List Users

List all users in the system.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: oauth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.UserManagementApi(swagger_client.ApiClient(configuration))

try:
    # List Users
    api_response = api_instance.l_ist_users()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UserManagementApi->l_ist_users: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2003**](InlineResponse2003.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **p_ost_user**
> InlineResponse201 p_ost_user(body=body)

Create User

Create a user. The new user can then make authenticated requests with access tokens retrieved from the /auth/token endpoint.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: oauth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.UserManagementApi(swagger_client.ApiClient(configuration))
body = swagger_client.Body2() # Body2 |  (optional)

try:
    # Create User
    api_response = api_instance.p_ost_user(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UserManagementApi->p_ost_user: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body2**](Body2.md)|  | [optional] 

### Return type

[**InlineResponse201**](InlineResponse201.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **p_ut_user**
> InlineResponse403 p_ut_user(id, body=body)

Set Quota

Set the quota for a user (number of resources a user can have).

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: oauth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.UserManagementApi(swagger_client.ApiClient(configuration))
id = 'id_example' # str | 
body = swagger_client.Body1() # Body1 |  (optional)

try:
    # Set Quota
    api_response = api_instance.p_ut_user(id, body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UserManagementApi->p_ut_user: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**|  | 
 **body** | [**Body1**](Body1.md)|  | [optional] 

### Return type

[**InlineResponse403**](InlineResponse403.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

