# swagger_client.RoutesApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**c_reate_route**](RoutesApi.md#c_reate_route) | **POST** /routes | Create Route
[**r_oute_key**](RoutesApi.md#r_oute_key) | **GET** /routes/{id} | Read Key


# **c_reate_route**
> InlineResponse2002 c_reate_route(body=body)

Create Route

Creates a public endpoint for a key.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: oauth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.RoutesApi(swagger_client.ApiClient(configuration))
body = swagger_client.Body1() # Body1 |  (optional)

try:
    # Create Route
    api_response = api_instance.c_reate_route(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling RoutesApi->c_reate_route: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body1**](Body1.md)|  | [optional] 

### Return type

[**InlineResponse2002**](InlineResponse2002.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **r_oute_key**
> r_oute_key(id)

Read Key

Reads a key from a public route.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.RoutesApi()
id = 'id_example' # str | 

try:
    # Read Key
    api_instance.r_oute_key(id)
except ApiException as e:
    print("Exception when calling RoutesApi->r_oute_key: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

