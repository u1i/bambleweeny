# swagger_client.ConfigurationApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**p_ut_config_admin**](ConfigurationApi.md#p_ut_config_admin) | **PUT** /config/admin | Change Admin Password


# **p_ut_config_admin**
> p_ut_config_admin(body=body)

Change Admin Password

Update the admin password - default password is 'changeme'.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: oauth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ConfigurationApi(swagger_client.ApiClient(configuration))
body = swagger_client.Body3() # Body3 |  (optional)

try:
    # Change Admin Password
    api_instance.p_ut_config_admin(body=body)
except ApiException as e:
    print("Exception when calling ConfigurationApi->p_ut_config_admin: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body3**](Body3.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

