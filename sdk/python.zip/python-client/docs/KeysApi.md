# swagger_client.KeysApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**d_el_key**](KeysApi.md#d_el_key) | **DELETE** /keys/(id} | Delete Key
[**i_ncr_key**](KeysApi.md#i_ncr_key) | **GET** /incr/(id} | Increase Key
[**r_ead_key**](KeysApi.md#r_ead_key) | **GET** /keys/ | List Keys
[**r_ead_key_0**](KeysApi.md#r_ead_key_0) | **GET** /keys/(id} | Read Key
[**w_rite_key**](KeysApi.md#w_rite_key) | **PUT** /keys/(id} | Write Key


# **d_el_key**
> object d_el_key()

Delete Key

Deletes a key.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: oauth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.KeysApi(swagger_client.ApiClient(configuration))

try:
    # Delete Key
    api_response = api_instance.d_el_key()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling KeysApi->d_el_key: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

**object**

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **i_ncr_key**
> i_ncr_key()

Increase Key

Increments the number stored at key by one.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: oauth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.KeysApi(swagger_client.ApiClient(configuration))

try:
    # Increase Key
    api_instance.i_ncr_key()
except ApiException as e:
    print("Exception when calling KeysApi->i_ncr_key: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: text/plain

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **r_ead_key**
> InlineResponse2001 r_ead_key()

List Keys

List all keys.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: oauth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.KeysApi(swagger_client.ApiClient(configuration))

try:
    # List Keys
    api_response = api_instance.r_ead_key()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling KeysApi->r_ead_key: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2001**](InlineResponse2001.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **r_ead_key_0**
> r_ead_key_0()

Read Key

Read a key.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: oauth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.KeysApi(swagger_client.ApiClient(configuration))

try:
    # Read Key
    api_instance.r_ead_key_0()
except ApiException as e:
    print("Exception when calling KeysApi->r_ead_key_0: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: text/plain

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **w_rite_key**
> w_rite_key()

Write Key

Set key to a specific value. Key names contain numbers, characters, underscores and colons. Valid key names are 'foo', 'my_key1', 'debug:b1:Hello' 'RogerRabbit'.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: oauth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.KeysApi(swagger_client.ApiClient(configuration))

try:
    # Write Key
    api_instance.w_rite_key()
except ApiException as e:
    print("Exception when calling KeysApi->w_rite_key: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

