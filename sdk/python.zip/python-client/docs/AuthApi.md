# swagger_client.AuthApi

All URIs are relative to *https://localhost/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**p_ost_auth_token**](AuthApi.md#p_ost_auth_token) | **POST** /auth/token | Get Access Token


# **p_ost_auth_token**
> InlineResponse2002 p_ost_auth_token(body=body)

Get Access Token

This endpoint is used to retrieve an access token to perform authenticated requests against the 'resources' endpoints. Login with username (email) and password. For admin, the username is simply 'admin'.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.AuthApi()
body = swagger_client.Body1() # Body1 |  (optional)

try:
    # Get Access Token
    api_response = api_instance.p_ost_auth_token(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AuthApi->p_ost_auth_token: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body1**](Body1.md)|  | [optional] 

### Return type

[**InlineResponse2002**](InlineResponse2002.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

