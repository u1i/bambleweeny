# swagger_client.DeprecatedApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**d_elete_resource**](DeprecatedApi.md#d_elete_resource) | **DELETE** /resources/{id} | Delete Resource
[**g_et_resource**](DeprecatedApi.md#g_et_resource) | **GET** /resources/{id} | Get Resource
[**l_ist_resources**](DeprecatedApi.md#l_ist_resources) | **GET** /resources | List Resources
[**p_ost_resource**](DeprecatedApi.md#p_ost_resource) | **POST** /resources | Create Resource


# **d_elete_resource**
> d_elete_resource(id)

Delete Resource

Delete a resource identified by a UUID.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: oauth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.DeprecatedApi(swagger_client.ApiClient(configuration))
id = 'id_example' # str | 

try:
    # Delete Resource
    api_instance.d_elete_resource(id)
except ApiException as e:
    print("Exception when calling DeprecatedApi->d_elete_resource: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **g_et_resource**
> InlineResponse2005 g_et_resource(id)

Get Resource

Retrieve a resource identified by the UUID.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: oauth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.DeprecatedApi(swagger_client.ApiClient(configuration))
id = 'id_example' # str | 

try:
    # Get Resource
    api_response = api_instance.g_et_resource(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DeprecatedApi->g_et_resource: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**|  | 

### Return type

[**InlineResponse2005**](InlineResponse2005.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **l_ist_resources**
> InlineResponse2004 l_ist_resources()

List Resources

List all resources of the user. Admin will see a list of resources for all users.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: oauth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.DeprecatedApi(swagger_client.ApiClient(configuration))

try:
    # List Resources
    api_response = api_instance.l_ist_resources()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DeprecatedApi->l_ist_resources: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2004**](InlineResponse2004.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **p_ost_resource**
> object p_ost_resource(body=body)

Create Resource

Create a resource from JSON data.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: oauth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.DeprecatedApi(swagger_client.ApiClient(configuration))
body = swagger_client.Body4() # Body4 |  (optional)

try:
    # Create Resource
    api_response = api_instance.p_ost_resource(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DeprecatedApi->p_ost_resource: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body4**](Body4.md)|  | [optional] 

### Return type

**object**

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

