# swagger_client.ListsApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**d_elete_lists_id**](ListsApi.md#d_elete_lists_id) | **DELETE** /lists/{id} | Delete List
[**g_et_lists**](ListsApi.md#g_et_lists) | **GET** /lists | Get All Lists
[**g_et_lists_id**](ListsApi.md#g_et_lists_id) | **GET** /lists/{id} | Get Item from List
[**p_ost_lists_id**](ListsApi.md#p_ost_lists_id) | **POST** /lists/{id} | Add Item to List


# **d_elete_lists_id**
> object d_elete_lists_id(id)

Delete List

Removes a list.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ListsApi()
id = 'id_example' # str | 

try:
    # Delete List
    api_response = api_instance.d_elete_lists_id(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ListsApi->d_elete_lists_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**|  | 

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: text/plain
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **g_et_lists**
> g_et_lists()

Get All Lists

Gets all lists.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ListsApi()

try:
    # Get All Lists
    api_instance.g_et_lists()
except ApiException as e:
    print("Exception when calling ListsApi->g_et_lists: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: text/plain
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **g_et_lists_id**
> g_et_lists_id(id)

Get Item from List

Retrieves the last item from a list (\"pop\").

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ListsApi()
id = 'id_example' # str | 

try:
    # Get Item from List
    api_instance.g_et_lists_id(id)
except ApiException as e:
    print("Exception when calling ListsApi->g_et_lists_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: text/plain
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **p_ost_lists_id**
> p_ost_lists_id(id)

Add Item to List

Adds an item to a list (\"push\"). The list will be created if it doesn't exist yet.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ListsApi()
id = 'id_example' # str | 

try:
    # Add Item to List
    api_instance.p_ost_lists_id(id)
except ApiException as e:
    print("Exception when calling ListsApi->p_ost_lists_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: text/plain
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

