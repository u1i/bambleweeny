# swagger-java-client

## Requirements

Building the API client library requires [Maven](https://maven.apache.org/) to be installed.

## Installation

To install the API client library to your local Maven repository, simply execute:

```shell
mvn install
```

To deploy it to a remote Maven repository instead, configure the settings of the repository and execute:

```shell
mvn deploy
```

Refer to the [official documentation](https://maven.apache.org/plugins/maven-deploy-plugin/usage.html) for more information.

### Maven users

Add this dependency to your project's POM:

```xml
<dependency>
    <groupId>io.swagger</groupId>
    <artifactId>swagger-java-client</artifactId>
    <version>1.0.0</version>
    <scope>compile</scope>
</dependency>
```

### Gradle users

Add this dependency to your project's build file:

```groovy
compile "io.swagger:swagger-java-client:1.0.0"
```

### Others

At first generate the JAR by executing:

    mvn package

Then manually install the following JARs:

* target/swagger-java-client-1.0.0.jar
* target/lib/*.jar

## Getting Started

Please follow the [installation](#installation) instruction and execute the following Java code:

```java

import io.swagger.client.*;
import io.swagger.client.auth.*;
import io.swagger.client.model.*;
import io.swagger.client.api.AuthenticationApi;

import java.io.File;
import java.util.*;

public class AuthenticationApiExample {

    public static void main(String[] args) {
        
        AuthenticationApi apiInstance = new AuthenticationApi();
        Body body = new Body(); // Body | 
        try {
            InlineResponse200 result = apiInstance.pOSTAuthToken(body);
            System.out.println(result);
        } catch (ApiException e) {
            System.err.println("Exception when calling AuthenticationApi#pOSTAuthToken");
            e.printStackTrace();
        }
    }
}

```

## Documentation for API Endpoints

All URIs are relative to *https://localhost*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*AuthenticationApi* | [**pOSTAuthToken**](docs/AuthenticationApi.md#pOSTAuthToken) | **POST** /auth/token | Get Access Token
*ConfigurationApi* | [**pUTConfigAdmin**](docs/ConfigurationApi.md#pUTConfigAdmin) | **PUT** /config/admin | Change Admin Password
*DeprecatedApi* | [**dELETEResource**](docs/DeprecatedApi.md#dELETEResource) | **DELETE** /resources/{id} | Delete Resource
*DeprecatedApi* | [**gETResource**](docs/DeprecatedApi.md#gETResource) | **GET** /resources/{id} | Get Resource
*DeprecatedApi* | [**lISTResources**](docs/DeprecatedApi.md#lISTResources) | **GET** /resources | List Resources
*DeprecatedApi* | [**pOSTResource**](docs/DeprecatedApi.md#pOSTResource) | **POST** /resources | Create Resource
*KeysApi* | [**dELKey**](docs/KeysApi.md#dELKey) | **DELETE** /keys/(id} | Delete Key
*KeysApi* | [**iNCRKey**](docs/KeysApi.md#iNCRKey) | **GET** /incr/(id} | Increase Key
*KeysApi* | [**rEADKey**](docs/KeysApi.md#rEADKey) | **GET** /keys/ | List Keys
*KeysApi* | [**rEADKey_0**](docs/KeysApi.md#rEADKey_0) | **GET** /keys/(id} | Read Key
*KeysApi* | [**wRITEKey**](docs/KeysApi.md#wRITEKey) | **PUT** /keys/(id} | Write Key
*UserManagementApi* | [**dELETEUser**](docs/UserManagementApi.md#dELETEUser) | **DELETE** /users/{id} | Delete User
*UserManagementApi* | [**gETUser**](docs/UserManagementApi.md#gETUser) | **GET** /users/{id} | Get User
*UserManagementApi* | [**lISTUsers**](docs/UserManagementApi.md#lISTUsers) | **GET** /users | List Users
*UserManagementApi* | [**pOSTUser**](docs/UserManagementApi.md#pOSTUser) | **POST** /users | Create User
*UserManagementApi* | [**pUTUser**](docs/UserManagementApi.md#pUTUser) | **PUT** /users/{id} | Set Quota


## Documentation for Models

 - [Body](docs/Body.md)
 - [Body1](docs/Body1.md)
 - [Body2](docs/Body2.md)
 - [Body3](docs/Body3.md)
 - [Body4](docs/Body4.md)
 - [InlineResponse200](docs/InlineResponse200.md)
 - [InlineResponse2001](docs/InlineResponse2001.md)
 - [InlineResponse2001Keys](docs/InlineResponse2001Keys.md)
 - [InlineResponse2002](docs/InlineResponse2002.md)
 - [InlineResponse2003](docs/InlineResponse2003.md)
 - [InlineResponse2003Users](docs/InlineResponse2003Users.md)
 - [InlineResponse2004](docs/InlineResponse2004.md)
 - [InlineResponse2004Resources](docs/InlineResponse2004Resources.md)
 - [InlineResponse2005](docs/InlineResponse2005.md)
 - [InlineResponse201](docs/InlineResponse201.md)
 - [InlineResponse403](docs/InlineResponse403.md)


## Documentation for Authorization

Authentication schemes defined for the API:
### oauth2

- **Type**: OAuth
- **Flow**: password
- **Authorization URL**: 
- **Scopes**: N/A


## Recommendation

It's recommended to create an instance of `ApiClient` per thread in a multithreaded environment to avoid any potential issues.

## Author



