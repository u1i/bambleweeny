# swagger-java-client

## Requirements

Building the API client library requires [Maven](https://maven.apache.org/) to be installed.

## Installation

To install the API client library to your local Maven repository, simply execute:

```shell
mvn install
```

To deploy it to a remote Maven repository instead, configure the settings of the repository and execute:

```shell
mvn deploy
```

Refer to the [official documentation](https://maven.apache.org/plugins/maven-deploy-plugin/usage.html) for more information.

### Maven users

Add this dependency to your project's POM:

```xml
<dependency>
    <groupId>io.swagger</groupId>
    <artifactId>swagger-java-client</artifactId>
    <version>1.0.0</version>
    <scope>compile</scope>
</dependency>
```

### Gradle users

Add this dependency to your project's build file:

```groovy
compile "io.swagger:swagger-java-client:1.0.0"
```

### Others

At first generate the JAR by executing:

    mvn package

Then manually install the following JARs:

* target/swagger-java-client-1.0.0.jar
* target/lib/*.jar

## Getting Started

Please follow the [installation](#installation) instruction and execute the following Java code:

```java

import io.swagger.client.*;
import io.swagger.client.auth.*;
import io.swagger.client.model.*;
import io.swagger.client.api.AuthApi;

import java.io.File;
import java.util.*;

public class AuthApiExample {

    public static void main(String[] args) {
        
        AuthApi apiInstance = new AuthApi();
        Body1 body = new Body1(); // Body1 | 
        try {
            InlineResponse2002 result = apiInstance.pOSTAuthToken(body);
            System.out.println(result);
        } catch (ApiException e) {
            System.err.println("Exception when calling AuthApi#pOSTAuthToken");
            e.printStackTrace();
        }
    }
}

```

## Documentation for API Endpoints

All URIs are relative to *https://localhost/v1*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*AuthApi* | [**pOSTAuthToken**](docs/AuthApi.md#pOSTAuthToken) | **POST** /auth/token | Get Access Token
*ResourcesApi* | [**dELETEResource**](docs/ResourcesApi.md#dELETEResource) | **DELETE** /resources/{id} | Delete Resource
*ResourcesApi* | [**gETResource**](docs/ResourcesApi.md#gETResource) | **GET** /resources/{id} | Get Resource
*ResourcesApi* | [**lISTResources**](docs/ResourcesApi.md#lISTResources) | **GET** /resources | List Resources
*ResourcesApi* | [**pOSTResource**](docs/ResourcesApi.md#pOSTResource) | **POST** /resources | Create Resource
*UsersApi* | [**dELETEUser**](docs/UsersApi.md#dELETEUser) | **DELETE** /users/{id} | Delete User
*UsersApi* | [**gETUser**](docs/UsersApi.md#gETUser) | **GET** /users/{id} | Get User
*UsersApi* | [**lISTUsers**](docs/UsersApi.md#lISTUsers) | **GET** /users | List Users
*UsersApi* | [**pOSTUser**](docs/UsersApi.md#pOSTUser) | **POST** /users | Create User
*UsersApi* | [**pUTUser**](docs/UsersApi.md#pUTUser) | **PUT** /users/{id} | Set Quota


## Documentation for Models

 - [Body](docs/Body.md)
 - [Body1](docs/Body1.md)
 - [Body2](docs/Body2.md)
 - [Body3](docs/Body3.md)
 - [InlineResponse200](docs/InlineResponse200.md)
 - [InlineResponse2001](docs/InlineResponse2001.md)
 - [InlineResponse2001Resources](docs/InlineResponse2001Resources.md)
 - [InlineResponse2002](docs/InlineResponse2002.md)
 - [InlineResponse2003](docs/InlineResponse2003.md)
 - [InlineResponse2004](docs/InlineResponse2004.md)
 - [InlineResponse2004Users](docs/InlineResponse2004Users.md)
 - [InlineResponse201](docs/InlineResponse201.md)
 - [InlineResponse403](docs/InlineResponse403.md)


## Documentation for Authorization

Authentication schemes defined for the API:
### oauth2

- **Type**: OAuth
- **Flow**: password
- **Authorization URL**: 
- **Scopes**: N/A


## Recommendation

It's recommended to create an instance of `ApiClient` per thread in a multithreaded environment to avoid any potential issues.

## Author



