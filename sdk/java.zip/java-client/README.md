# swagger-java-client

## Requirements

Building the API client library requires [Maven](https://maven.apache.org/) to be installed.

## Installation

To install the API client library to your local Maven repository, simply execute:

```shell
mvn install
```

To deploy it to a remote Maven repository instead, configure the settings of the repository and execute:

```shell
mvn deploy
```

Refer to the [official documentation](https://maven.apache.org/plugins/maven-deploy-plugin/usage.html) for more information.

### Maven users

Add this dependency to your project's POM:

```xml
<dependency>
    <groupId>io.swagger</groupId>
    <artifactId>swagger-java-client</artifactId>
    <version>1.0.0</version>
    <scope>compile</scope>
</dependency>
```

### Gradle users

Add this dependency to your project's build file:

```groovy
compile "io.swagger:swagger-java-client:1.0.0"
```

### Others

At first generate the JAR by executing:

    mvn package

Then manually install the following JARs:

* target/swagger-java-client-1.0.0.jar
* target/lib/*.jar

## Getting Started

Please follow the [installation](#installation) instruction and execute the following Java code:

```java

import io.swagger.client.*;
import io.swagger.client.auth.*;
import io.swagger.client.model.*;
import io.swagger.client.api.AdministrationApi;

import java.io.File;
import java.util.*;

public class AdministrationApiExample {

    public static void main(String[] args) {
        ApiClient defaultClient = Configuration.getDefaultApiClient();
        
        // Configure OAuth2 access token for authorization: oauth2
        OAuth oauth2 = (OAuth) defaultClient.getAuthentication("oauth2");
        oauth2.setAccessToken("YOUR ACCESS TOKEN");

        AdministrationApi apiInstance = new AdministrationApi();
        Body4 body = new Body4(); // Body4 | 
        try {
            apiInstance.cHANGEAdminPw(body);
        } catch (ApiException e) {
            System.err.println("Exception when calling AdministrationApi#cHANGEAdminPw");
            e.printStackTrace();
        }
    }
}

```

## Documentation for API Endpoints

All URIs are relative to *https://localhost*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*AdministrationApi* | [**cHANGEAdminPw**](docs/AdministrationApi.md#cHANGEAdminPw) | **PUT** /config/admin | Change Admin Password
*AdministrationApi* | [**dELETEUser**](docs/AdministrationApi.md#dELETEUser) | **DELETE** /users/{id} | Delete User
*AdministrationApi* | [**gETInfo**](docs/AdministrationApi.md#gETInfo) | **GET** /info | Get Info
*AdministrationApi* | [**gETUser**](docs/AdministrationApi.md#gETUser) | **GET** /users/{id} | Get User
*AdministrationApi* | [**lISTUsers**](docs/AdministrationApi.md#lISTUsers) | **GET** /users | List Users
*AdministrationApi* | [**pOSTUser**](docs/AdministrationApi.md#pOSTUser) | **POST** /users | Create User
*AdministrationApi* | [**pUTUser**](docs/AdministrationApi.md#pUTUser) | **PUT** /users/{id} | Set Quota
*AdministrationApi* | [**sAVE**](docs/AdministrationApi.md#sAVE) | **GET** /save | Save to Disk
*AuthenticationApi* | [**pOSTAuthToken**](docs/AuthenticationApi.md#pOSTAuthToken) | **POST** /auth/token | Get Access Token
*KeysApi* | [**dELKey**](docs/KeysApi.md#dELKey) | **DELETE** /keys/{id} | Delete Key
*KeysApi* | [**iNCRKey**](docs/KeysApi.md#iNCRKey) | **GET** /incr/{id} | Increase Key
*KeysApi* | [**rEADKey**](docs/KeysApi.md#rEADKey) | **GET** /keys/{id} | Read Key
*KeysApi* | [**rEADKey_0**](docs/KeysApi.md#rEADKey_0) | **GET** /keys/ | List Keys
*KeysApi* | [**wRITEKey**](docs/KeysApi.md#wRITEKey) | **PUT** /keys/{id} | Write Key
*ListsApi* | [**dELETEListsId**](docs/ListsApi.md#dELETEListsId) | **DELETE** /lists/{id} | Delete List
*ListsApi* | [**gETLists**](docs/ListsApi.md#gETLists) | **GET** /lists | Get All Lists
*ListsApi* | [**gETListsId**](docs/ListsApi.md#gETListsId) | **GET** /lists/{id} | Get Item from List
*ListsApi* | [**pOSTListsId**](docs/ListsApi.md#pOSTListsId) | **POST** /lists/{id} | Add Item to List
*RoutesApi* | [**cREATERoute**](docs/RoutesApi.md#cREATERoute) | **POST** /routes | Create Route
*RoutesApi* | [**rOUTEKey**](docs/RoutesApi.md#rOUTEKey) | **GET** /routes/{id} | Read Key


## Documentation for Models

 - [Body](docs/Body.md)
 - [Body1](docs/Body1.md)
 - [Body2](docs/Body2.md)
 - [Body3](docs/Body3.md)
 - [Body4](docs/Body4.md)
 - [InlineResponse200](docs/InlineResponse200.md)
 - [InlineResponse2001](docs/InlineResponse2001.md)
 - [InlineResponse2001Keys](docs/InlineResponse2001Keys.md)
 - [InlineResponse2002](docs/InlineResponse2002.md)
 - [InlineResponse2003](docs/InlineResponse2003.md)
 - [InlineResponse2003Users](docs/InlineResponse2003Users.md)
 - [InlineResponse2004](docs/InlineResponse2004.md)
 - [InlineResponse201](docs/InlineResponse201.md)
 - [InlineResponse403](docs/InlineResponse403.md)


## Documentation for Authorization

Authentication schemes defined for the API:
### oauth2

- **Type**: OAuth
- **Flow**: password
- **Authorization URL**: 
- **Scopes**: N/A


## Recommendation

It's recommended to create an instance of `ApiClient` per thread in a multithreaded environment to avoid any potential issues.

## Author



