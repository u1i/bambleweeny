
# InlineResponse2004

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**users** | [**List&lt;InlineResponse2004Users&gt;**](InlineResponse2004Users.md) |  |  [optional]



