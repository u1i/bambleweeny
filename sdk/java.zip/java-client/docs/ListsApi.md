# ListsApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**dELETEListsId**](ListsApi.md#dELETEListsId) | **DELETE** /lists/{id} | Delete List
[**gETLists**](ListsApi.md#gETLists) | **GET** /lists | Get All Lists
[**gETListsId**](ListsApi.md#gETListsId) | **GET** /lists/{id} | Get Item from List
[**pOSTListsId**](ListsApi.md#pOSTListsId) | **POST** /lists/{id} | Add Item to List


<a name="dELETEListsId"></a>
# **dELETEListsId**
> Object dELETEListsId(id)

Delete List

Removes a list.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ListsApi;


ListsApi apiInstance = new ListsApi();
String id = "id_example"; // String | 
try {
    Object result = apiInstance.dELETEListsId(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ListsApi#dELETEListsId");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

**Object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: text/plain
 - **Accept**: application/json

<a name="gETLists"></a>
# **gETLists**
> gETLists()

Get All Lists

Gets all lists.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ListsApi;


ListsApi apiInstance = new ListsApi();
try {
    apiInstance.gETLists();
} catch (ApiException e) {
    System.err.println("Exception when calling ListsApi#gETLists");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: text/plain
 - **Accept**: application/json

<a name="gETListsId"></a>
# **gETListsId**
> gETListsId(id)

Get Item from List

Retrieves the last item from a list (\&quot;pop\&quot;).

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ListsApi;


ListsApi apiInstance = new ListsApi();
String id = "id_example"; // String | 
try {
    apiInstance.gETListsId(id);
} catch (ApiException e) {
    System.err.println("Exception when calling ListsApi#gETListsId");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: text/plain
 - **Accept**: application/json

<a name="pOSTListsId"></a>
# **pOSTListsId**
> pOSTListsId(id)

Add Item to List

Adds an item to a list (\&quot;push\&quot;). The list will be created if it doesn&#39;t exist yet.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ListsApi;


ListsApi apiInstance = new ListsApi();
String id = "id_example"; // String | 
try {
    apiInstance.pOSTListsId(id);
} catch (ApiException e) {
    System.err.println("Exception when calling ListsApi#pOSTListsId");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: text/plain
 - **Accept**: application/json

