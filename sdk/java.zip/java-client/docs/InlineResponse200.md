
# InlineResponse200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accessToken** | **String** |  |  [optional]
**tokenType** | **String** |  |  [optional]



