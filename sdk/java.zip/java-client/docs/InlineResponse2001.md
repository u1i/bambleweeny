
# InlineResponse2001

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resources** | [**List&lt;InlineResponse2001Resources&gt;**](InlineResponse2001Resources.md) |  |  [optional]



