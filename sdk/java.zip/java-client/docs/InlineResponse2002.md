
# InlineResponse2002

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resources** | [**List&lt;InlineResponse2002Resources&gt;**](InlineResponse2002Resources.md) |  |  [optional]



