
# InlineResponse2002

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**info** | **String** |  |  [optional]
**path** | **String** |  |  [optional]



