
# InlineResponse2003

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**users** | [**List&lt;InlineResponse2003Users&gt;**](InlineResponse2003Users.md) |  |  [optional]



