# KeysApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**dELKey**](KeysApi.md#dELKey) | **DELETE** /keys/(id} | Delete Key
[**iNCRKey**](KeysApi.md#iNCRKey) | **GET** /incr/(id} | Increase Key
[**rEADKey**](KeysApi.md#rEADKey) | **GET** /keys/ | List Keys
[**rEADKey_0**](KeysApi.md#rEADKey_0) | **GET** /keys/(id} | Read Key
[**wRITEKey**](KeysApi.md#wRITEKey) | **PUT** /keys/(id} | Write Key


<a name="dELKey"></a>
# **dELKey**
> Object dELKey()

Delete Key

Deletes a key.

### Example
```java
// Import classes:
//import io.swagger.client.api.KeysApi;

KeysApi apiInstance = new KeysApi();
try {
    Object result = apiInstance.dELKey();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling KeysApi#dELKey");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

**Object**

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="iNCRKey"></a>
# **iNCRKey**
> iNCRKey()

Increase Key

Increments the number stored at key by one.

### Example
```java
// Import classes:
//import io.swagger.client.api.KeysApi;

KeysApi apiInstance = new KeysApi();
try {
    apiInstance.iNCRKey();
} catch (ApiException e) {
    System.err.println("Exception when calling KeysApi#iNCRKey");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: text/plain

<a name="rEADKey"></a>
# **rEADKey**
> InlineResponse2001 rEADKey()

List Keys

List all keys.

### Example
```java
// Import classes:
//import io.swagger.client.api.KeysApi;

KeysApi apiInstance = new KeysApi();
try {
    InlineResponse2001 result = apiInstance.rEADKey();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling KeysApi#rEADKey");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2001**](InlineResponse2001.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="rEADKey_0"></a>
# **rEADKey_0**
> rEADKey_0()

Read Key

Read a key.

### Example
```java
// Import classes:
//import io.swagger.client.api.KeysApi;

KeysApi apiInstance = new KeysApi();
try {
    apiInstance.rEADKey_0();
} catch (ApiException e) {
    System.err.println("Exception when calling KeysApi#rEADKey_0");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: text/plain

<a name="wRITEKey"></a>
# **wRITEKey**
> wRITEKey()

Write Key

Set key to a specific value. Key names contain numbers, characters, underscores and colons. Valid key names are &#39;foo&#39;, &#39;my_key1&#39;, &#39;debug:b1:Hello&#39; &#39;RogerRabbit&#39;.

### Example
```java
// Import classes:
//import io.swagger.client.api.KeysApi;

KeysApi apiInstance = new KeysApi();
try {
    apiInstance.wRITEKey();
} catch (ApiException e) {
    System.err.println("Exception when calling KeysApi#wRITEKey");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

