# RoutesApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cREATERoute**](RoutesApi.md#cREATERoute) | **POST** /routes | Create Route
[**rOUTEKey**](RoutesApi.md#rOUTEKey) | **GET** /routes/{id} | Read Key


<a name="cREATERoute"></a>
# **cREATERoute**
> InlineResponse2002 cREATERoute(body)

Create Route

Creates a public endpoint for a key.

### Example
```java
// Import classes:
//import io.swagger.client.api.RoutesApi;

RoutesApi apiInstance = new RoutesApi();
Body1 body = new Body1(); // Body1 | 
try {
    InlineResponse2002 result = apiInstance.cREATERoute(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling RoutesApi#cREATERoute");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body1**](Body1.md)|  | [optional]

### Return type

[**InlineResponse2002**](InlineResponse2002.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="rOUTEKey"></a>
# **rOUTEKey**
> rOUTEKey(id)

Read Key

Reads a key from a public route.

### Example
```java
// Import classes:
//import io.swagger.client.api.RoutesApi;

RoutesApi apiInstance = new RoutesApi();
String id = "id_example"; // String | 
try {
    apiInstance.rOUTEKey(id);
} catch (ApiException e) {
    System.err.println("Exception when calling RoutesApi#rOUTEKey");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

