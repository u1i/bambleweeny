
# Body2

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**quota** | **String** |  | 



