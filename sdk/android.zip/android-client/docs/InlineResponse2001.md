
# InlineResponse2001

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**keys** | [**List&lt;InlineResponse2001Keys&gt;**](InlineResponse2001Keys.md) |  |  [optional]



