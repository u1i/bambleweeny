# AdministrationApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cHANGEAdminPw**](AdministrationApi.md#cHANGEAdminPw) | **PUT** /config/admin | Change Admin Password
[**dELETEUser**](AdministrationApi.md#dELETEUser) | **DELETE** /users/{id} | Delete User
[**gETInfo**](AdministrationApi.md#gETInfo) | **GET** /info | Get Info
[**gETUser**](AdministrationApi.md#gETUser) | **GET** /users/{id} | Get User
[**lISTUsers**](AdministrationApi.md#lISTUsers) | **GET** /users | List Users
[**pOSTUser**](AdministrationApi.md#pOSTUser) | **POST** /users | Create User
[**pUTUser**](AdministrationApi.md#pUTUser) | **PUT** /users/{id} | Set Quota
[**sAVE**](AdministrationApi.md#sAVE) | **GET** /save | Save to Disk


<a name="cHANGEAdminPw"></a>
# **cHANGEAdminPw**
> cHANGEAdminPw(body)

Change Admin Password

Update the admin password - default password is &#39;changeme&#39;.

### Example
```java
// Import classes:
//import io.swagger.client.api.AdministrationApi;

AdministrationApi apiInstance = new AdministrationApi();
Body4 body = new Body4(); // Body4 | 
try {
    apiInstance.cHANGEAdminPw(body);
} catch (ApiException e) {
    System.err.println("Exception when calling AdministrationApi#cHANGEAdminPw");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body4**](Body4.md)|  | [optional]

### Return type

null (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="dELETEUser"></a>
# **dELETEUser**
> dELETEUser(id)

Delete User

Delete a user record identified by a numceric user id.

### Example
```java
// Import classes:
//import io.swagger.client.api.AdministrationApi;

AdministrationApi apiInstance = new AdministrationApi();
String id = "id_example"; // String | 
try {
    apiInstance.dELETEUser(id);
} catch (ApiException e) {
    System.err.println("Exception when calling AdministrationApi#dELETEUser");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

null (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="gETInfo"></a>
# **gETInfo**
> gETInfo()

Get Info

Gets detailed information on the backend Redis connection, including memory used, number of connections etc.

### Example
```java
// Import classes:
//import io.swagger.client.api.AdministrationApi;

AdministrationApi apiInstance = new AdministrationApi();
try {
    apiInstance.gETInfo();
} catch (ApiException e) {
    System.err.println("Exception when calling AdministrationApi#gETInfo");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="gETUser"></a>
# **gETUser**
> InlineResponse2004 gETUser(id)

Get User

Get a user record identified by a numceric user id.

### Example
```java
// Import classes:
//import io.swagger.client.api.AdministrationApi;

AdministrationApi apiInstance = new AdministrationApi();
String id = "id_example"; // String | 
try {
    InlineResponse2004 result = apiInstance.gETUser(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AdministrationApi#gETUser");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**InlineResponse2004**](InlineResponse2004.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="lISTUsers"></a>
# **lISTUsers**
> InlineResponse2003 lISTUsers()

List Users

List all users in the system.

### Example
```java
// Import classes:
//import io.swagger.client.api.AdministrationApi;

AdministrationApi apiInstance = new AdministrationApi();
try {
    InlineResponse2003 result = apiInstance.lISTUsers();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AdministrationApi#lISTUsers");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2003**](InlineResponse2003.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="pOSTUser"></a>
# **pOSTUser**
> InlineResponse201 pOSTUser(body)

Create User

Create a user. The new user can then make authenticated requests with access tokens retrieved from the /auth/token endpoint.

### Example
```java
// Import classes:
//import io.swagger.client.api.AdministrationApi;

AdministrationApi apiInstance = new AdministrationApi();
Body2 body = new Body2(); // Body2 | 
try {
    InlineResponse201 result = apiInstance.pOSTUser(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AdministrationApi#pOSTUser");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body2**](Body2.md)|  | [optional]

### Return type

[**InlineResponse201**](InlineResponse201.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="pUTUser"></a>
# **pUTUser**
> InlineResponse403 pUTUser(id, body)

Set Quota

Set the quota for a user (number of resources a user can have).

### Example
```java
// Import classes:
//import io.swagger.client.api.AdministrationApi;

AdministrationApi apiInstance = new AdministrationApi();
String id = "id_example"; // String | 
Body3 body = new Body3(); // Body3 | 
try {
    InlineResponse403 result = apiInstance.pUTUser(id, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AdministrationApi#pUTUser");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |
 **body** | [**Body3**](Body3.md)|  | [optional]

### Return type

[**InlineResponse403**](InlineResponse403.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="sAVE"></a>
# **sAVE**
> sAVE()

Save to Disk

Triggers a save to disk for the backend Redis in-memory database.

### Example
```java
// Import classes:
//import io.swagger.client.api.AdministrationApi;

AdministrationApi apiInstance = new AdministrationApi();
try {
    apiInstance.sAVE();
} catch (ApiException e) {
    System.err.println("Exception when calling AdministrationApi#sAVE");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

