# AuthApi

All URIs are relative to *https://localhost/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**pOSTAuthToken**](AuthApi.md#pOSTAuthToken) | **POST** /auth/token | Get Access Token


<a name="pOSTAuthToken"></a>
# **pOSTAuthToken**
> InlineResponse2002 pOSTAuthToken(body)

Get Access Token

This endpoint is used to retrieve an access token to perform authenticated requests against the &#39;resources&#39; endpoints. Login with username (email) and password. For admin, the username is simply &#39;admin&#39;.

### Example
```java
// Import classes:
//import io.swagger.client.api.AuthApi;

AuthApi apiInstance = new AuthApi();
Body1 body = new Body1(); // Body1 | 
try {
    InlineResponse2002 result = apiInstance.pOSTAuthToken(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AuthApi#pOSTAuthToken");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body1**](Body1.md)|  | [optional]

### Return type

[**InlineResponse2002**](InlineResponse2002.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

