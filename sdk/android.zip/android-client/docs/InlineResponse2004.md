
# InlineResponse2004

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resources** | [**List&lt;InlineResponse2004Resources&gt;**](InlineResponse2004Resources.md) |  |  [optional]



