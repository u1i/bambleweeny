
# InlineResponse200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**content** | **String** |  |  [optional]
**owner** | **String** |  |  [optional]
**acl** | **String** |  |  [optional]



