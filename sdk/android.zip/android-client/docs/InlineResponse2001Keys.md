
# InlineResponse2001Keys

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**owner** | **String** |  |  [optional]
**key** | **String** |  |  [optional]



