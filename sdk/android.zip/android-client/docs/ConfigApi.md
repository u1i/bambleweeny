# ConfigApi

All URIs are relative to *https://localhost/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**pUTConfigAdmin**](ConfigApi.md#pUTConfigAdmin) | **PUT** /config/admin | Change Admin Password


<a name="pUTConfigAdmin"></a>
# **pUTConfigAdmin**
> pUTConfigAdmin(body)

Change Admin Password

Update the admin password - default password is &#39;changeme&#39;.

### Example
```java
// Import classes:
//import io.swagger.client.api.ConfigApi;

ConfigApi apiInstance = new ConfigApi();
Body4 body = new Body4(); // Body4 | 
try {
    apiInstance.pUTConfigAdmin(body);
} catch (ApiException e) {
    System.err.println("Exception when calling ConfigApi#pUTConfigAdmin");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body4**](Body4.md)|  | [optional]

### Return type

null (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

